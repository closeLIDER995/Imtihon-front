import React from 'react'
import Header from '../Components/Header'

const About = () => {
  return (
    <div>
    <Header />
    <h1>About Page</h1>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Possimus libero minima provident facere, fuga quidem eos ea sapiente. Perspiciatis, officia.</p>
    </div>
  )
}

export default About